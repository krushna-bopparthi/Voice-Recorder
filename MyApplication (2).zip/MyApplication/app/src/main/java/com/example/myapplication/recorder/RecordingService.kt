package com.example.myapplication.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.MediaRecorder
import android.net.Uri
import android.os.IBinder
import android.util.Log
import androidx.core.content.ContextCompat
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import java.io.File

@AndroidEntryPoint
class RecordingService : Service() {

    private var mediaRecorder: MediaRecorder? = null
    private lateinit var outputFile: File
    private var amplitudeJob: Job? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startRecording()
            ACTION_STOP -> {
                stopRecording()
                stopSelf()
            }
            else -> startRecording() // default safety
        }
        return START_STICKY
    }

    private fun startRecording() {
        try {
            val outputDir = File(filesDir, "recordings")
            if (!outputDir.exists()) outputDir.mkdirs()
            outputFile = File(outputDir, "audio_${System.currentTimeMillis()}.m4a")

            mediaRecorder = MediaRecorder().apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setOutputFile(outputFile.absolutePath)
                prepare()
                start()
            }

            Log.d("RecordingService", "Recording started: ${outputFile.absolutePath}")

            // ✅ Start amplitude monitoring
            amplitudeJob = CoroutineScope(Dispatchers.IO).launch {
                while (isActive) {
                    delay(500)
                    val amp = mediaRecorder?.maxAmplitude ?: 0
                    Log.d("AudioDebug", "Mic amplitude: $amp")
                }
            }

        } catch (e: Exception) {
            Log.e("RecordingService", "Error starting recording: ${e.message}", e)
        }
    }

    fun stopRecording() {
        try {
            Log.d("RecordingService", "Stopping recording...")

            amplitudeJob?.cancel()
            amplitudeJob = null

            mediaRecorder?.stop()
            mediaRecorder?.release()
            mediaRecorder = null

            Log.d("RecordingService", "Recording stopped and saved: ${outputFile.absolutePath}")

            val uri = Uri.fromFile(outputFile)
            val intent = Intent("com.example.myapplication.RECORDING_COMPLETED")
            intent.putExtra("audio_uri", uri.toString())
            sendBroadcast(intent)

        } catch (e: Exception) {
            Log.e("RecordingService", "Error stopping recording: ${e.message}", e)
        }
    }

    override fun onDestroy() {
        amplitudeJob?.cancel()
        mediaRecorder?.release()
        mediaRecorder = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ✅ Add this companion object
    companion object {
        private const val ACTION_START = "com.example.myapplication.REC_START"
        private const val ACTION_STOP = "com.example.myapplication.REC_STOP"

        fun start(context: Context) {
            val intent = Intent(context, RecordingService::class.java).apply {
                action = ACTION_START
            }
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, RecordingService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }
}
