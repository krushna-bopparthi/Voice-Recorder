package com.example.myapplication.net

import com.example.myapplication.BuildConfig

object ApiChooser {
    fun transcription(): TranscriptionApi {
        return if (BuildConfig.OPENAI_API_KEY.isNotBlank()) {
            OpenAiTranscriptionApi()
        } else {
            MockTranscriptionApi()
        }
    }
    fun summary(): SummaryApi {
        return if (BuildConfig.OPENAI_API_KEY.isNotBlank()) {
            OpenAiSummaryApi()
        } else {
            MockSummaryApi()
        }
    }
}
