package com.example.myapplication.data.remote

import okhttp3.MediaType
import okhttp3.RequestBody
import okio.BufferedSink
import okio.source
import java.io.File

/**
 * Custom RequestBody that streams file data safely
 * to prevent ProtocolException (size mismatch).
 */
class SafeFileRequestBody(
    private val file: File,
    private val contentType: MediaType?
) : RequestBody() {

    override fun contentType(): MediaType? = contentType

    override fun contentLength(): Long = file.length()

    override fun writeTo(sink: BufferedSink) {
        file.inputStream().use { input ->
            sink.writeAll(input.source())
        }
    }
}
