package com.example.myapplication

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.myapplication.data.Meeting
import com.example.myapplication.service.RecordingService
import com.example.myapplication.ui.RecordingViewModel
import com.example.myapplication.ui.theme.MyApplicationTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    private val vm: RecordingViewModel by viewModels()

    // Permission launcher
    private val permissionLauncher = registerForActivityResult(RequestMultiplePermissions()) { results ->
        // Optional: log or show UI feedback if user denies permissions
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestPerms()

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val meetings by vm.meetings.collectAsState(initial = emptyList())
                    val isRecording by vm.isRecording.collectAsState(initial = false)

                    MainScreen(
                        onStart = { handleStartRecording() },
                        onStop = { handleStopRecording() },
                        isRecording = isRecording,
                        meetings = meetings
                    )
                }
            }
        }
    }

    /**
     * Start Recording
     */
    private fun handleStartRecording() {
        val hasMicPermission = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (hasMicPermission) {
            // ✅ Start the foreground recording service
            RecordingService.start(this)
            vm.startRecording()
        } else {
            requestPerms()
        }
    }

    /**
     * Stop Recording
     */
    private fun handleStopRecording() {
        // ✅ Stop the service and ViewModel process
        RecordingService.stop(this)
        vm.stopRecording()
    }

    /**
     * Request runtime permissions
     */
    private fun requestPerms() {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) {
            perms += Manifest.permission.POST_NOTIFICATIONS
        }
        permissionLauncher.launch(perms.toTypedArray())
    }
}

@Composable
fun MainScreen(
    onStart: () -> Unit,
    onStop: () -> Unit,
    isRecording: Boolean,
    meetings: List<Meeting>
) {
    Scaffold { pad ->
        Column(
            Modifier
                .padding(pad)
                .padding(16.dp)
                .fillMaxSize()
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = onStart,
                    modifier = Modifier.weight(1f),
                    enabled = !isRecording
                ) {
                    Text("Start Recording")
                }
                OutlinedButton(
                    onClick = onStop,
                    modifier = Modifier.weight(1f),
                    enabled = isRecording
                ) {
                    Text("Stop")
                }
            }

            Spacer(Modifier.height(16.dp))
            Text(
                "Sessions",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(8.dp))

            if (meetings.isEmpty()) {
                Box(
                    Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No sessions yet. Tap Start Recording.")
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(meetings.size) { idx ->
                        MeetingCard(meetings[idx])
                    }
                }
            }
        }
    }
}

@Composable
fun MeetingCard(m: Meeting) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text("Audio: ${m.audioUri}", style = MaterialTheme.typography.bodySmall)

            if (m.transcript != null) {
                Text("Transcript:", fontWeight = FontWeight.SemiBold)
                Text(m.transcript, Modifier.padding(bottom = 8.dp))
            }

            if (m.summaryTitle != null) {
                Text("Title: ${m.summaryTitle}", fontWeight = FontWeight.SemiBold)
                m.summaryBody?.let { Text(it) }
                m.actionItems?.let { Text("Action Items:\n$it") }
                m.keyPoints?.let { Text("Key Points:\n$it") }
            } else {
                Text(
                    "Processing transcript/summary...",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
