package com.example.myapplication.repo

import com.example.myapplication.net.SummaryApi
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SummaryRepository @Inject constructor(
    private val api: SummaryApi
) {
    /**
     * Generate structured meeting summary from a transcript using OpenAI GPT.
     */
    suspend fun generateSummary(transcript: String): String {
        return try {
            val result = api.summarize(transcript)
            """
                📋 ${result.title}

                📝 Summary:
                ${result.summary}

                🔑 Key Points:
                ${result.keyPoints.joinToString("\n")}

                ✅ Action Items:
                ${result.actionItems.joinToString("\n")}
            """.trimIndent()
        } catch (e: Exception) {
            "Error generating summary: ${e.localizedMessage}"
        }
    }
}
