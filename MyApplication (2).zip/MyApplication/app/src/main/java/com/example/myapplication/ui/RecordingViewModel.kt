package com.example.myapplication.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication.repo.MeetingRepository
   // ✅ fixed import
import com.example.myapplication.data.repository.WhisperRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import com.example.myapplication.repo.SummaryRepository


@HiltViewModel
class RecordingViewModel @Inject constructor(
    private val meetingRepository: MeetingRepository,
    private val whisperRepository: WhisperRepository,
    private val summaryRepository: SummaryRepository
) : ViewModel() {

    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording

    private val _transcript = MutableStateFlow("")
    val transcript: StateFlow<String> = _transcript

    val meetings = meetingRepository.getAllMeetings()   // ✅ fixed

    fun startRecording() {
        viewModelScope.launch {
            _isRecording.value = true
            meetingRepository.startRecording()           // ✅ fixed
        }
    }

    fun stopRecording() {
        viewModelScope.launch {
            _isRecording.value = false
            val audioUri = meetingRepository.stopRecording()

            if (audioUri != null) {
                _transcript.value = "🎙️ Transcribing..."
                try {
                    // Step 1 — Get transcript from audio
                    val text = whisperRepository.transcribeAudio(audioUri)
                    _transcript.value = "✅ Transcription complete.\n\n$text"

                    // Step 2 — Generate AI Summary
                    _transcript.value = "🧠 Generating summary..."
                    val summary = summaryRepository.generateSummary(text)

                    // Step 3 — Update UI with summary
                    _transcript.value = summary

                } catch (e: Exception) {
                    _transcript.value = "❌ Error: ${e.localizedMessage}"
                }
            } else {
                _transcript.value = "No audio file found"
            }
        }
    }

}
