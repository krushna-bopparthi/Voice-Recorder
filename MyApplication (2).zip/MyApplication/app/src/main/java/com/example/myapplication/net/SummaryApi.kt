package com.example.myapplication.net

interface SummaryApi {
    suspend fun summarize(transcript: String): SummaryResult
}

data class SummaryResult(
    val title: String,
    val summary: String,
    val actionItems: List<String>,
    val keyPoints: List<String>
)
