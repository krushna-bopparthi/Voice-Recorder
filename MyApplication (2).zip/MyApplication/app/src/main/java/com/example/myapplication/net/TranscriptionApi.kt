package com.example.myapplication.net

import android.content.Context
import android.net.Uri

interface TranscriptionApi {
    suspend fun transcribe(context: Context, audioUri: Uri): String
}
