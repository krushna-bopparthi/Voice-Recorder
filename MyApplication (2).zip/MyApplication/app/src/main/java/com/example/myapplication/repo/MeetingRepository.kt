package com.example.myapplication.repo

import android.content.Context
import android.media.MediaRecorder
import android.util.Log
import com.example.myapplication.data.Meeting
import com.example.myapplication.service.RecordingService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton
import dagger.hilt.android.qualifiers.ApplicationContext
import com.example.myapplication.data.MeetingDao
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.net.Uri
import androidx.core.net.toUri

@Singleton
class MeetingRepository @Inject constructor(
    @ApplicationContext private val context: Context,

    private val dao: MeetingDao

) {
    private var mediaRecorder: MediaRecorder? = null
    private var currentFile: File? = null
    // Simulate stored meetings
    private val _meetings = MutableStateFlow<List<Meeting>>(emptyList())
    val meetings: StateFlow<List<Meeting>> = _meetings.asStateFlow()

    // Start recording by launching the service
    fun startRecording() {
        try {
            val dir = File(context.getExternalFilesDir(null), "recordings")
            if (!dir.exists()) dir.mkdirs()

            val fileName = "rec_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.m4a"
            currentFile = File(dir, fileName)

            mediaRecorder = MediaRecorder().apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setOutputFile(currentFile!!.absolutePath)
                prepare()
                start()
            }
        } catch (e: Exception) {
            Log.e("MeetingRepository", "Error starting recording", e)
        }
    }

    // Stop recording service
    fun stopRecording(): Uri? {
        return try {
            mediaRecorder?.apply {
                stop()
                release()
            }
            mediaRecorder = null
            currentFile?.toUri()
        } catch (e: Exception) {
            Log.e("MeetingRepository", "Error stopping recording", e)
            null
        }
    }

    // Return all meetings
    fun getAllMeetings(): StateFlow<List<Meeting>> = meetings
}
