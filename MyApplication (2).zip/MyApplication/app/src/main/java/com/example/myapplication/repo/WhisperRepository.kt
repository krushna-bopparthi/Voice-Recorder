package com.example.myapplication.data.repository

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.myapplication.api.WhisperApi
import dagger.hilt.android.scopes.ViewModelScoped
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.create
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton
import okio.BufferedSink
import okio.source
//import com.example.myapplication.data.remote.WhisperApi
import com.example.myapplication.data.remote.SafeFileRequestBody
import dagger.hilt.android.qualifiers.ApplicationContext


@Singleton
class WhisperRepository @Inject constructor(
    private val api: WhisperApi,
    @ApplicationContext private val context: Context
)
 {
    // ⚠️ DO NOT stop or release MediaRecorder here.
    // The file should already be finalized before this is called.

    suspend fun transcribeAudio(uri: Uri): String = withContext(Dispatchers.IO) {
        try {
            val file = File(uri.path ?: throw IllegalArgumentException("Invalid file URI"))
            Log.d("WhisperRepo", "Preparing to upload file: ${file.absolutePath}, size=${file.length()} bytes")

            val requestBody = SafeFileRequestBody(file, "audio/m4a".toMediaType())
            val multipart = MultipartBody.Part.createFormData("file", file.name, requestBody)
            val model = create("text/plain".toMediaType(), "whisper-1")

            val response = api.transcribeAudio(multipart, model)
            Log.d("WhisperRepo", "Transcription response: ${response.text}")
            return@withContext response.text
        } catch (e: Exception) {
            Log.e("WhisperRepo", "Whisper API failed: ${e.message}", e)
            return@withContext "Error: ${e.message}"
        }
    }
}
