package com.example.myapplication.net

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.delay

class MockTranscriptionApi : TranscriptionApi {
    override suspend fun transcribe(context: Context, audioUri: Uri): String {
        delay(1500)
        return "Mock transcript for audio file: $audioUri"
    }
}

class MockSummaryApi : SummaryApi {
    override suspend fun summarize(transcript: String): SummaryResult {
        return SummaryResult(
            title = "Meeting Summary (Mock)",
            summary = "This is a mock summary for demonstration.",
            actionItems = listOf("Follow up on key points", "Send summary email"),
            keyPoints = listOf("Introductions", "Agenda discussed", "Next steps")
        )
    }
}
