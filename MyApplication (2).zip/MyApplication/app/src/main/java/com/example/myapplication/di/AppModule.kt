package com.example.myapplication.di

import android.content.Context
import androidx.room.Room
import com.example.myapplication.BuildConfig
import com.example.myapplication.api.WhisperApi
import com.example.myapplication.data.AppDb
import com.example.myapplication.data.MeetingDao
import com.example.myapplication.data.repository.WhisperRepository
import com.example.myapplication.net.OpenAiSummaryApi
import com.example.myapplication.net.OpenAiTranscriptionApi
import com.example.myapplication.net.SummaryApi
import com.example.myapplication.net.TranscriptionApi
import com.example.myapplication.repo.SummaryRepository

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    // 🧩 ROOM DATABASE
    @Provides
    @Singleton
    fun provideDb(@ApplicationContext ctx: Context): AppDb =
        Room.databaseBuilder(ctx, AppDb::class.java, "app.db").build()

    @Provides
    fun provideMeetingDao(db: AppDb): MeetingDao = db.meetingDao()

    // 🧩 BASE OKHTTP CLIENT (shared by both Whisper & OpenAI)
    @Provides
    @Singleton
    fun provideOkHttpClient(): OkHttpClient {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }



        val authInterceptor = Interceptor { chain ->
            val apiKey = BuildConfig.OPENAI_API_KEY
            val request = chain.request().newBuilder()
                .addHeader("Authorization", "Bearer $apiKey")
                .addHeader("Content-Type", "application/json")
                .build()
            chain.proceed(request)
        }


        return OkHttpClient.Builder()
            .addInterceptor(authInterceptor)
            .addInterceptor(logging)
            .build()
    }

    // 🧩 MOSHI (shared by both Retrofit instances)
    @Provides
    @Singleton
    fun provideMoshi(): Moshi =
        Moshi.Builder().add(KotlinJsonAdapterFactory()).build()

    // 🧩 RETROFIT FOR WHISPER API
//    @Provides
//    @Singleton
//    fun provideWhisperRetrofit(client: OkHttpClient, moshi: Moshi): Retrofit =
//        Retrofit.Builder()
//            .baseUrl("https://api.openai.com/") // OpenAI Whisper endpoint
//            .addConverterFactory(MoshiConverterFactory.create(moshi))
//            .client(client)
//            .build()

    @Provides
    @Singleton
    fun provideWhisperApi(retrofit: Retrofit): WhisperApi =
        retrofit.create(WhisperApi::class.java)

    // 🧩 RETROFIT FOR OPENAI CHAT COMPLETIONS (GPT-4)
//    @Provides
//    @Singleton
//    fun provideOpenAiRetrofit(client: OkHttpClient, moshi: Moshi): Retrofit =
//        Retrofit.Builder()
//            .baseUrl("https://api.openai.com/") // GPT endpoint uses same host
//            .addConverterFactory(MoshiConverterFactory.create(moshi))
//            .client(client)
//            .build()

    @Provides
    @Singleton
    fun provideOpenAiTranscriptionApi(): TranscriptionApi = OpenAiTranscriptionApi()


    @Provides
    @Singleton
    fun provideRetrofit(client: OkHttpClient, moshi: Moshi): Retrofit =
        Retrofit.Builder()
            .baseUrl("https://api.openai.com/")
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .client(client)
            .build()


    // ✅ Provide OpenAI API
    @Provides
    @Singleton
    fun provideOpenAiSummaryApi(client: OkHttpClient): SummaryApi = OpenAiSummaryApi(client)

    // 🧩 Provide Summary Repository
    @Provides
    @Singleton
    fun provideSummaryRepository(api: SummaryApi): SummaryRepository = SummaryRepository(api)
}
