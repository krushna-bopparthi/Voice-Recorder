package com.example.myapplication.net

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import retrofit2.http.Body
import retrofit2.http.Headers
import retrofit2.http.POST

/**
 * Minimal OpenAI Chat Completions API surface for JSON responses.
 * We ask the model to return a single JSON object we can parse safely.
 */
interface OpenAiApi {
    @Headers("Accept: application/json")
    @POST("v1/chat/completions")
    suspend fun chatCompletions(@Body body: ChatRequest): ChatResponse
}

@JsonClass(generateAdapter = true)
data class ChatRequest(
    val model: String,
    val messages: List<ChatMessage>,
    @Json(name = "temperature") val temperature: Double? = 0.2,
    // We are NOT streaming here (keeps WorkManager simple & robust).
    val stream: Boolean? = null,
    // Ask for JSON-formatted output guidance
    @Json(name = "response_format") val responseFormat: ResponseFormat? = ResponseFormat("json_object"),
    // Optional: small max_tokens to keep bill low
    @Json(name = "max_tokens") val maxTokens: Int? = 800
)

@JsonClass(generateAdapter = true)
data class ChatMessage(
    val role: String,   // "system" | "user" | "assistant"
    val content: String
)

@JsonClass(generateAdapter = true)
data class ResponseFormat(@Json(name = "type") val type: String)

@JsonClass(generateAdapter = true)
data class ChatResponse(
    val id: String?,
    val choices: List<Choice>,
    val usage: Usage?
) {
    @JsonClass(generateAdapter = true)
    data class Choice(
        val index: Int,
        val message: ChatMessage,
        @Json(name = "finish_reason") val finishReason: String?
    )

    @JsonClass(generateAdapter = true)
    data class Usage(
        @Json(name = "prompt_tokens") val promptTokens: Int?,
        @Json(name = "completion_tokens") val completionTokens: Int?,
        @Json(name = "total_tokens") val totalTokens: Int?
    )
}
