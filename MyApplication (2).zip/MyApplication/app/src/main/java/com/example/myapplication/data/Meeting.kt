package com.example.myapplication.data


import androidx.room.Entity
import androidx.room.PrimaryKey
import java.time.Instant

@Entity(tableName = "meetings")
data class Meeting(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val audioUri: String,             // file:// or content://
    val durationSec: Int,
    val transcript: String? = null,
    val summaryTitle: String? = null,
    val summaryBody: String? = null,
    val actionItems: String? = null,  // newline separated
    val keyPoints: String? = null     // newline separated
)

